1. How to Setup?

	"Chatter\README.txt"

	Please keep Chatroom Files in this directory, all files must be placed here to work.
	You can create a short cut to both files if needed.


2. How to clear chat history?

	Go to "Chatter\cdata\chat_data", open "chat_tags.key" and delete all messages, then save it.

3. If you have any problems DM me on discord or send a message on mail:
	Discord: Paython#2796
	Gmail:   paython2796@gmail.com