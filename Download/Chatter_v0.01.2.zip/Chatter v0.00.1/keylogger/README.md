Little trojan thingy that infects USB drives when run.
How to use:
Extract
Run build.bat
DM slenny#4173 for help